package com.forgeessentials.worldcontrol;

//Depreciated

import com.forgeessentials.util.BackupArea;

import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;

public class BackupList implements Queue<BackupArea> {

    @Override
    public boolean addAll(Collection<? extends BackupArea> arg0)
    {
        return false;
    }

    @Override
    public void clear()
    {
    }

    @Override
    public boolean contains(Object arg0)
    {
        return false;
    }

    @Override
    public boolean containsAll(Collection<?> arg0)
    {

        return false;
    }

    @Override
    public boolean isEmpty()
    {

        return false;
    }

    @Override
    public Iterator<BackupArea> iterator()
    {

        return null;
    }

    @Override
    public boolean remove(Object arg0)
    {

        return false;
    }

    @Override
    public boolean removeAll(Collection<?> arg0)
    {

        return false;
    }

    @Override
    public boolean retainAll(Collection<?> arg0)
    {

        return false;
    }

    @Override
    public int size()
    {

        return 0;
    }

    @Override
    public Object[] toArray()
    {

        return null;
    }

    @Override
    public <T> T[] toArray(T[] arg0)
    {

        return null;
    }

    @Override
    public boolean add(BackupArea e)
    {

        return false;
    }

    @Override
    public BackupArea element()
    {

        return null;
    }

    @Override
    public boolean offer(BackupArea e)
    {

        return false;
    }

    @Override
    public BackupArea peek()
    {

        return null;
    }

    @Override
    public BackupArea poll()
    {

        return null;
    }

    @Override
    public BackupArea remove()
    {

        return null;
    }

}
