package com.ForgeEssentials.property;

import com.ForgeEssentials.core.IFEModule;

import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartedEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.event.FMLServerStoppingEvent;

public class ModuleProperty implements IFEModule
{

	@Override
	public void preLoad(FMLPreInitializationEvent e)
	{
	}

	@Override
	public void load(FMLInitializationEvent e)
	{
	}

	@Override
	public void postLoad(FMLPostInitializationEvent e)
	{
	}

	@Override
	public void serverStarting(FMLServerStartingEvent e)
	{
	}

	@Override
	public void serverStarted(FMLServerStartedEvent e)
	{
	}

	@Override
	public void serverStopping(FMLServerStoppingEvent e) {
		// TODO Auto-generated method stub
		
	}
}
