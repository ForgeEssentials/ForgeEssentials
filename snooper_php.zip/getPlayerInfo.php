<?php
	// Edit this ->
	define( 'MQ_SERVER_ADDR', '192.168.0.110' );
	define( 'MQ_SERVER_PORT', 25565 );
	define( 'MQ_TIMEOUT', 1 );
	// Edit this <-
	
	// Display everything in browser, because some people can't look in logs for errors
	Error_Reporting( E_ALL | E_STRICT );
	Ini_Set( 'display_errors', true );
	
	require __DIR__ . '/ForgeEssentialsQuery.class.php';
		
	$Timer = MicroTime( true );
	$Query = new ForgeEssentialsQuery();
	
	try
	{
		$info = $Query->GetInfo( MQ_SERVER_ADDR, MQ_SERVER_PORT, MQ_TIMEOUT, 0x05, $_GET["player"]);
		$armor = $Query->GetInfo( MQ_SERVER_ADDR, MQ_SERVER_PORT, MQ_TIMEOUT, 0x06, $_GET["player"]);
		$inv = $Query->GetInfo( MQ_SERVER_ADDR, MQ_SERVER_PORT, MQ_TIMEOUT, 0x07, $_GET["player"]);
	}
	catch( Exception $e )
	{
		$error = $e->getMessage();
	}
	
	function printTable($data)
	{
		echo '<table class="table table-bordered table-striped">';
		foreach($data as $key => $value)
		{
			if(is_numeric($key))
			{
				echo '<tr><td class="span4">';
				if(Is_Array($value))
				{
					printTable($value);
				}
				else
				{
					echo $value;
				}
				echo "</td></tr>";
			}
			else
			{
				echo '<tr><td class="span4">';
				echo  $GLOBALS['Query']->GetName($key);
				echo "</td><td>";
				if(Is_Array($value))
				{
					printTable($value);
				}
				else
				{
					echo $value;
				}
				echo "</td></tr>";
			}
		}
		echo '</table>';
	}
?>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Snooper Test</title>
	
	<link rel="stylesheet" href="bootstrap.css">
	<style type="text/css">
		footer {
			margin-top: 45px;
			padding: 35px 0 36px;
			border-top: 1px solid #e5e5e5;
		}
		footer p {
			margin-bottom: 0;
			color: #555;
		}
	</style>
</head>
<body>
    <div class="container">
    	<div class="page-header">
			<h1>Snooper Test</h1>
		</div>
		<div class="span12">
			<?php if( isset( $GLOBALS['error'] ) ): ?>
			<div class="alert alert-info">
				<h4 class="alert-heading">Exception:</h4>
				<?php echo htmlspecialchars( $GLOBALS['error'] ); ?>
			</div>
			<?php else: ?>
			<div>
				<h5>Player info:</h5>
				<? printTable($GLOBALS['info']); ?>
			</div>
			<div>
				<h5>Armor info:</h5>
				<? printTable($GLOBALS['armor']); ?>
			</div>
			<div>
				<h5>Inventory info:</h5>
				<? printTable($GLOBALS['inv']); ?>
			</div>
			<div>
				<h5>RAW player info:</h5>
				<pre><? print_r($GLOBALS['info']); ?>
				</pre>
			</div>
			<div>
				<h5>RAW armor info:</h5>
				<pre><? print_r($GLOBALS['armor']); ?>
				</pre>
			</div>
			<div>
				<h5>RAW inv info:</h5>
				<pre><? print_r($GLOBALS['inv']); ?>
				</pre>
			</div>
		</div>
	</div>
	<?php endif; ?>
	<footer>
			<p class="pull-right"><span class="badge badge-info">Generated in <?php echo Number_Format( ( MicroTime( true ) - $Timer ), 4, '.', '' ); ?>s</span></p>
	</footer>
</html>