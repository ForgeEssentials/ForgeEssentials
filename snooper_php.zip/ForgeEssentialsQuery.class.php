<?php
class ForgeEssentialsQueryException extends Exception
{
	// Exception thrown by ForgeEssentialsQuery class
}

class ForgeEssentialsQuery
{
	/*
	 * Originally written by xPaw, Rewritten for FE by Dries007
	 * 
	 * Dries007:
	 * Website: http://www.dries007.net
	 * GitHub: https://github.com/dries007/
	 * 
	 * xPaw:
	 * Website: http://xpaw.ru
	 * GitHub: https://github.com/xPaw/PHP-Minecraft-Query
	 */
	
	const STATISTIC = 0x00;
	const HANDSHAKE = 0x09;
	
	private $Socket;
	private $Data;
	
	private $names = Array(
		'maxplayers' 	=> 'Playerslots',
		'version'     	=> 'MCVersion',
		'uptime'	   	=> 'Uptime',
		'map'    		=> 'Worldname',
		'motd'    		=> 'Servermessage',
		'mods' 			=> 'Mods',
		'hostip' 		=> 'HostIp',
		'hostport'   	=> 'HostPort',
		'numplayers'    => 'Players',
		'diff'    		=> 'Difficulty',
		'tps'		   	=> 'Ticks per sec.',
		'home' 			=> 'Home',
		'lastDeath'		=> 'LastDeath',
		'armor'    		=> 'Armor value',
		'wallet'    	=> 'Money',
		'health'    	=> 'Health',
		'pos' 			=> 'Position',
		'potion' 		=> 'Potions',
		'ping'   		=> 'Ping',
		'gm'     		=> 'Gamemode',
		'inv'     		=> 'Inventory',
		'id'     		=> 'Item ID',
		'dam'     		=> 'Damage',
		'xp'     		=> 'Xp',
		'wb'     		=> 'WorldBorder',
		'cap'     		=> 'Capabilities',
		'ench'     		=> 'Enchantments'
	);
	
	public function GetName($key)
	{
		if(array_key_exists($key, $this->names))
		{
			echo $this->names[$key];
		}
		else
		{
			echo $key;
		}
	}
	
	public function GetInfo( $Ip, $Port = 25565, $Timeout = 3, $type = 0x00, $extradata = "")
	{
		if( !is_int( $Timeout ) || $Timeout < 0 )
		{
			throw new InvalidArgumentException( 'Timeout must be an integer.' );
		}
		
		$this->Socket = @FSockOpen( 'udp://' . $Ip, (int)$Port, $ErrNo, $ErrStr, $Timeout );
		
		if( $ErrNo || $this->Socket === false )
		{
			throw new ForgeEssentialsQueryException( 'Could not create socket: ' . $ErrStr );
		}
		
		Stream_Set_Timeout( $this->Socket, $Timeout );
		Stream_Set_Blocking( $this->Socket, true );
		
		try
		{
			$Challenge = $this->GetChallenge( );
			$this->GetStatus($Challenge, $type, $extradata);
			
		}
		// We catch this because we want to close the socket, not very elegant
		catch( ForgeEssentialsQueryException $e )
		{
			FClose( $this->Socket );
			
			throw new ForgeEssentialsQueryException( $e->getMessage( ) );
		}
		
		FClose( $this->Socket );
		return $this->Data;
	}
	
	private function GetChallenge( )
	{
		$Data = $this->WriteData( self :: HANDSHAKE );
		
		if( $Data === false )
		{
			throw new ForgeEssentialsQueryException( "Failed to receive challenge." );
		}
		
		return Pack( 'N', $Data );
	}
	
	private function GetStatus($Challenge, $type, $extradata)
	{
		$Data = $this->WriteData($type, $Challenge . Pack( 'c*') . $extradata);
		
		if( !$Data )
		{
			throw new ForgeEssentialsQueryException( "Failed to receive status." );
		}
		
		$this->Data = Array( );		
		$this->Data = json_decode(trim($Data), true);
	}
	
	private function WriteData( $Command, $Append = "" )
	{
		$Command = Pack( 'c*', 0xFE, 0xFD, $Command, 0x01, 0x02, 0x03, 0x04 ) . $Append;
		$Length  = StrLen( $Command );
		
		if( $Length !== FWrite( $this->Socket, $Command, $Length ) )
		{
			throw new ForgeEssentialsQueryException( "Failed to write on socket." );
		}
		
		$Data = FRead( $this->Socket, 2048 );
		
		if( $Data === false )
		{
			throw new ForgeEssentialsQueryException( "Failed to read from socket." );
		}
		
		if( StrLen( $Data ) < 5)
		{
			return false;
		}
		
		return SubStr( $Data, 5 );
	}
}
