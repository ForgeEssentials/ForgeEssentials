package maximumtechmodding.worldcontrol;

public enum CoordinateType {
	X, 
	Y, 
	Z;
}
