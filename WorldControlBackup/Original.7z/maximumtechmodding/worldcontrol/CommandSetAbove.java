package maximumtechmodding.worldcontrol;

import net.minecraft.src.CommandBase;
import net.minecraft.src.ICommandSender;

public class CommandSetAbove extends CommandBase {

	@Override
	public String getCommandName() {
		return "setabove";
	}

	@Override
	public void processCommand(ICommandSender var1, String[] var2) {
		try{
			CommandInfo inf = null;
			int radius=0;
			if(var2.length==2) {
				inf = CommandProcesser.processIDMetaCombo(var2[0]);
				radius = Integer.parseInt(var2[1]);
			}else{
				 this.getCommandSenderAsPlayer(var1).addChatMessage("SetAbove Command Failed(Try /setabove <id(:meta)> <radius>)");
				 return;
			}
			FunctionHandler.instance.setAboveCommand(radius, inf, this.getCommandSenderAsPlayer(var1));
		}catch(Exception e) {
			this.getCommandSenderAsPlayer(var1).addChatMessage("SetAbove Command Failed!(Unknown Reason)");
			e.printStackTrace();
		}
	}

}
