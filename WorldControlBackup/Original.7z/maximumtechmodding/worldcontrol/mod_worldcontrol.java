package maximumtechmodding.worldcontrol;

import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import net.minecraft.server.MinecraftServer;
import net.minecraft.src.CommandBase;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EnumToolMaterial;
import net.minecraft.src.ItemAxe;
import net.minecraft.src.MLProp;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModLoader;
import net.minecraft.src.ServerCommandManager;
import net.minecraft.src.World;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Side;
import cpw.mods.fml.common.Mod.*;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.registry.TickRegistry;

@NetworkMod(clientSideRequired = true, serverSideRequired = false)
@Mod(modid = "WorldControl", name = "WorldControl", version = "1.1")
public class mod_worldcontrol {
	
	//@MLProp public static int wandID = 500;
	
	public static float renderPartialTicks = 1F;
	
	//public static final net.minecraft.src.Item wand = (new ItemWand(wandID)).setItemName("wand");
	
	public static mod_worldcontrol instance;
	
	@Init
	public void load(cpw.mods.fml.common.event.FMLInitializationEvent nothingHere) {
		instance=this;
		new FunctionHandler();
		//ModLoader.addName(wand, "WorldControl Wand");
		net.minecraft.src.Item.itemsList[15]=null;
		(new ItemWand(15)).setIconCoord(0, 7).setItemName("hatchetWood");
		TickRegistry.registerTickHandler(new TickHandler(), Side.CLIENT);
		NetworkRegistry.instance().registerChannel(new ClientPacketHandler(), "WCR");
		loadPlugins();
	}
	
	@ServerStarting
	public void serverLoad(FMLServerStartingEvent event) {
		loadCommands(event);
	}
	
	public void loadCommands(FMLServerStartingEvent event) {
		event.registerServerCommand(new CommandSet());
        event.registerServerCommand(new CommandReplace());
        event.registerServerCommand(new CommandCount());
        event.registerServerCommand(new CommandUndo());
        event.registerServerCommand(new CommandRedo());
        event.registerServerCommand(new CommandPos1());
        event.registerServerCommand(new CommandPos2());
        event.registerServerCommand(new CommandHPos1());
        event.registerServerCommand(new CommandHPos2());
        event.registerServerCommand(new CommandDimension());
        event.registerServerCommand(new CommandReplaceNear());
        event.registerServerCommand(new CommandSetNear());
        event.registerServerCommand(new CommandGreen());
        event.registerServerCommand(new CommandUngreen());
        event.registerServerCommand(new CommandDrain());
        event.registerServerCommand(new CommandSetHollow());
        event.registerServerCommand(new CommandExtend1());
        event.registerServerCommand(new CommandExtend2());
        event.registerServerCommand(new CommandSave());
        event.registerServerCommand(new CommandLoad());
        event.registerServerCommand(new CommandLoadRelative());
        event.registerServerCommand(new CommandCopy());
        event.registerServerCommand(new CommandPaste());
        event.registerServerCommand(new CommandTree());
        event.registerServerCommand(new CommandStack());
        event.registerServerCommand(new CommandCut());
        event.registerServerCommand(new CommandMove());
        event.registerServerCommand(new CommandOverlay());
        event.registerServerCommand(new CommandSetTop());
        event.registerServerCommand(new CommandTpSel1());
        event.registerServerCommand(new CommandTpSel2());
        event.registerServerCommand(new CommandUnsnow());
        event.registerServerCommand(new CommandSnow());
        event.registerServerCommand(new CommandUnice());
        event.registerServerCommand(new CommandIce());
        event.registerServerCommand(new CommandDistr());
        event.registerServerCommand(new CommandSetBelow());
        event.registerServerCommand(new CommandSetAbove());
        event.registerServerCommand(new CommandReplaceBelow());
        event.registerServerCommand(new CommandReplaceAbove());
        event.registerServerCommand(new CommandButcher());
        event.registerServerCommand(new CommandExtinguish());
        event.registerServerCommand(new CommandChunk());
        event.registerServerCommand(new CommandMiniChunk());
        event.registerServerCommand(new CommandSetReach());
        event.registerServerCommand(new CommandShift());
        event.registerServerCommand(new CommandRotate());
        event.registerServerCommand(new CommandFlip());
        for(int i = 0;i<plugins.size();i++) {
        	plugins.get(i).loadCommands(event);
        }
	}
	
	public static WCClassLoader CL = new WCClassLoader();
	
	public List<WCPlugin> plugins = new ArrayList<WCPlugin>();
	public void loadPlugins() {
		try{
			File dir =new File(System.getProperty("user.dir")+"\\WCplugins\\");
			if(!dir.exists()) {
				dir.mkdir();
			}
			if(dir.isDirectory()) {
				for (File child : dir.listFiles()) {
					if (".".equals(child.getName()) || "..".equals(child.getName())) {
						continue;
					}
					if(child.toString().endsWith(".jar")) {
						JarFile jar = new JarFile(child);
						for(Enumeration entry=jar.entries();entry.hasMoreElements();) {
							WCPlugin plugin = (WCPlugin)CL.loadClass("maximumtechmodding.worldcontrol.plugin_"+child.getName().substring(0, child.getName().length()-4), jar.getInputStream((JarEntry)entry.nextElement())).newInstance();
							plugins.add(plugin);
							plugin.helper=APIHelper.instance;
							plugin.load();
						}
						jar.close();
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
