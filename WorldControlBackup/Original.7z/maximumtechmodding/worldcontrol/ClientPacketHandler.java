package maximumtechmodding.worldcontrol;

import java.nio.ByteBuffer;

import net.minecraft.src.NetworkManager;
import net.minecraft.src.Packet250CustomPayload;
import cpw.mods.fml.common.network.IPacketHandler;
import cpw.mods.fml.common.network.Player;

public class ClientPacketHandler implements IPacketHandler {

	@Override
	public void onPacketData(NetworkManager manager, Packet250CustomPayload packet, Player player) {
		if(packet.channel.equals("WCR")) {
			ByteBuffer bb = ByteBuffer.allocate(4);
			bb.put(packet.data);
			ExtendedPlayerControllerMP.reachDistance = bb.getFloat(0);
		}
	}
	
}
