package maximumtechmodding.worldcontrol;

import java.util.EnumSet;

import net.minecraft.client.Minecraft;

import cpw.mods.fml.common.ITickHandler;
import cpw.mods.fml.common.TickType;

public class TickHandler implements ITickHandler {

	@Override
	public void tickStart(EnumSet<TickType> type, Object... tickData) {
		if(type.equals(EnumSet.of(TickType.RENDER))) {
			mod_worldcontrol.renderPartialTicks=(Float)tickData[0];
		}else if(type.equals(EnumSet.of(TickType.CLIENT))) {
			if(Minecraft.getMinecraft().playerController!=null&&!(Minecraft.getMinecraft().playerController instanceof ExtendedPlayerControllerMP)) {
				Minecraft.getMinecraft().playerController = new ExtendedPlayerControllerMP(Minecraft.getMinecraft(), Minecraft.getMinecraft().getSendQueue(), Minecraft.getMinecraft().playerController.isInCreativeMode());
			}
		}
	}

	@Override
	public void tickEnd(EnumSet<TickType> type, Object... tickData) {
		
	}

	@Override
	public EnumSet<TickType> ticks() {
		return EnumSet.of(TickType.RENDER, TickType.CLIENT);
	}

	@Override
	public String getLabel() {
		return null;
	}

}
