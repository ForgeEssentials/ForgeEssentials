package maximumtechmodding.worldcontrol;

public enum SelectionType {
	X1, 
	Y1, 
	Z1, 
	X2, 
	Y2, 
	Z2;
}
