package maximumtechmodding.worldcontrol;

import java.io.Serializable;

public class BlueprintBlock implements Serializable {
	int x=0;
	int y=0;
	int z=0;
	int blockID=0;
	int metadata=0;
	public BlueprintBlock(int X, int Y, int Z, int bid, int meta) {
		x=X;
		y=Y;
		z=Z;
		blockID=bid;
		metadata=meta;
	}
}
