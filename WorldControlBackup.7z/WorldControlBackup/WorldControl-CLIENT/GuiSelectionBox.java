package com.ForgeEssentials.WorldControl;

import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.ForgeSubscribe;

public class GuiSelectionBox
{
	@ForgeSubscribe
	public void renderBox(RenderWorldLastEvent event)
	{
		
	}

}
